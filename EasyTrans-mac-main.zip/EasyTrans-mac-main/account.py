# 申请网站 http://api.fanyi.baidu.com/api/trans
# 替换并加入更多的账号来分流预测， 用逗号隔开
appid = ['20191210000364718']
secretKey = ['e83BXpQFTnXrTy62O9MO']
